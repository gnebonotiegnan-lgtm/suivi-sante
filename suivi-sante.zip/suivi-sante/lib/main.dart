\
import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/intl.dart';
import 'package:local_auth/local_auth.dart';

const String kBoxName = 'measurements_box';
const String kKeyLockEnabled = 'lock_enabled';
const String kKeyPinHash = 'pin_hash';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  await Hive.openBox(kBoxName);
  runApp(const SuiviSanteApp());
}

/// ============================
/// Models (no codegen required)
/// ============================

enum MeasureType { bp, glucose }

enum GlucoseContext { fasting, beforeMeal, afterMeal, random }

class Measurement {
  final String id;
  final DateTime dateTime;
  final MeasureType type;

  // BP
  final int? sys;
  final int? dia;
  final int? pulse;

  // Glucose
  final double? glucose;
  final GlucoseContext? glucoseContext;

  // Common
  final String? note;

  const Measurement({
    required this.id,
    required this.dateTime,
    required this.type,
    this.sys,
    this.dia,
    this.pulse,
    this.glucose,
    this.glucoseContext,
    this.note,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'dateTime': dateTime.toIso8601String(),
        'type': type.name,
        'sys': sys,
        'dia': dia,
        'pulse': pulse,
        'glucose': glucose,
        'glucoseContext': glucoseContext?.name,
        'note': note,
      };

  static Measurement fromMap(Map<dynamic, dynamic> m) {
    final type = MeasureType.values.firstWhere((e) => e.name == (m['type'] as String));
    GlucoseContext? ctx;
    final ctxName = m['glucoseContext'] as String?;
    if (ctxName != null) {
      ctx = GlucoseContext.values.firstWhere((e) => e.name == ctxName);
    }
    return Measurement(
      id: m['id'] as String,
      dateTime: DateTime.parse(m['dateTime'] as String),
      type: type,
      sys: (m['sys'] as num?)?.toInt(),
      dia: (m['dia'] as num?)?.toInt(),
      pulse: (m['pulse'] as num?)?.toInt(),
      glucose: (m['glucose'] as num?)?.toDouble(),
      glucoseContext: ctx,
      note: m['note'] as String?,
    );
  }
}

/// ============================
/// Lock service (PIN + biometrics)
/// ============================

class LockService {
  final _storage = const FlutterSecureStorage();
  final _auth = LocalAuthentication();

  String _hash(String pin) => sha256.convert(utf8.encode(pin)).toString();

  Future<bool> isEnabled() async => (await _storage.read(key: kKeyLockEnabled)) == '1';

  Future<void> setEnabled(bool enabled) async =>
      _storage.write(key: kKeyLockEnabled, value: enabled ? '1' : '0');

  Future<bool> hasPin() async => (await _storage.read(key: kKeyPinHash)) != null;

  Future<void> setPin(String pin) async => _storage.write(key: kKeyPinHash, value: _hash(pin));

  Future<bool> verifyPin(String pin) async {
    final saved = await _storage.read(key: kKeyPinHash);
    if (saved == null) return false;
    return saved == _hash(pin);
  }

  Future<bool> canUseBiometrics() async {
    try {
      final can = await _auth.canCheckBiometrics;
      final supported = await _auth.isDeviceSupported();
      return can && supported;
    } catch (_) {
      return false;
    }
  }

  Future<bool> biometricAuth() async {
    try {
      return await _auth.authenticate(
        localizedReason: 'Déverrouiller l’application',
        options: const AuthenticationOptions(
          biometricOnly: true,
          stickyAuth: true,
        ),
      );
    } catch (_) {
      return false;
    }
  }
}

/// ============================
/// App
/// ============================

class SuiviSanteApp extends StatelessWidget {
  const SuiviSanteApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Suivi Santé',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.teal,
      ),
      home: const GateScreen(),
    );
  }
}

class GateScreen extends StatefulWidget {
  const GateScreen({super.key});
  @override
  State<GateScreen> createState() => _GateScreenState();
}

class _GateScreenState extends State<GateScreen> {
  final lock = LockService();
  bool loading = true;
  bool unlocked = false;

  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    final enabled = await lock.isEnabled();
    if (!enabled) {
      setState(() {
        unlocked = true;
        loading = false;
      });
      return;
    }

    if (await lock.canUseBiometrics()) {
      final ok = await lock.biometricAuth();
      if (ok) {
        setState(() {
          unlocked = true;
          loading = false;
        });
        return;
      }
    }

    setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (unlocked) return const HomeScreen();
    return PinUnlockScreen(lock: lock, onUnlocked: () => setState(() => unlocked = true));
  }
}

class PinUnlockScreen extends StatefulWidget {
  final LockService lock;
  final VoidCallback onUnlocked;
  const PinUnlockScreen({super.key, required this.lock, required this.onUnlocked});

  @override
  State<PinUnlockScreen> createState() => _PinUnlockScreenState();
}

class _PinUnlockScreenState extends State<PinUnlockScreen> {
  final ctrl = TextEditingController();
  String? err;

  @override
  void dispose() {
    ctrl.dispose();
    super.dispose();
  }

  Future<void> _unlock() async {
    final pin = ctrl.text.trim();
    if (pin.length < 4) {
      setState(() => err = 'PIN minimum 4 chiffres');
      return;
    }
    final ok = await widget.lock.verifyPin(pin);
    if (!ok) {
      setState(() => err = 'PIN incorrect');
      return;
    }
    widget.onUnlocked();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Verrouillage')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text('Entre ton PIN pour déverrouiller'),
            const SizedBox(height: 12),
            TextField(
              controller: ctrl,
              keyboardType: TextInputType.number,
              obscureText: true,
              decoration: InputDecoration(
                labelText: 'PIN',
                errorText: err,
                border: const OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            FilledButton(onPressed: _unlock, child: const Text('Déverrouiller')),
            const SizedBox(height: 8),
            OutlinedButton(
              onPressed: () async {
                if (await widget.lock.canUseBiometrics()) {
                  final ok = await widget.lock.biometricAuth();
                  if (ok) widget.onUnlocked();
                }
              },
              child: const Text('Utiliser empreinte/Face'),
            ),
          ],
        ),
      ),
    );
  }
}

/// ============================
/// Home
/// ============================

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      const HistoryScreen(),
      const ChartsScreen(),
      const AddMeasurementScreen(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Suivi Santé'),
        actions: [
          IconButton(
            icon: const Icon(Icons.lock),
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const SecurityScreen()));
            },
          ),
        ],
      ),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.history), label: 'Historique'),
          NavigationDestination(icon: Icon(Icons.show_chart), label: 'Graphiques'),
          NavigationDestination(icon: Icon(Icons.add), label: 'Ajouter'),
        ],
      ),
    );
  }
}

/// ============================
/// Data helpers (Hive dynamic box)
/// ============================

Box get _box => Hive.box(kBoxName);

List<Measurement> getAllMeasurements() {
  final values = _box.values.toList();
  final items = <Measurement>[];
  for (final v in values) {
    if (v is Map) {
      items.add(Measurement.fromMap(v));
    }
  }
  items.sort((a, b) => b.dateTime.compareTo(a.dateTime));
  return items;
}

void addMeasurement(Measurement m) => _box.add(m.toMap());

/// ============================
/// History
/// ============================

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder(
      valueListenable: _box.listenable(),
      builder: (context, Box b, _) {
        final items = getAllMeasurements();

        if (items.isEmpty) {
          return const Center(
            child: Text("Aucune donnée.\nAjoute une mesure 🙂", textAlign: TextAlign.center),
          );
        }

        return ListView.separated(
          padding: const EdgeInsets.all(12),
          itemCount: items.length,
          separatorBuilder: (_, __) => const SizedBox(height: 8),
          itemBuilder: (context, i) {
            final m = items[i];
            final dt = DateFormat('dd/MM/yyyy HH:mm').format(m.dateTime);

            final title = m.type == MeasureType.bp
                ? 'Tension: ${m.sys}/${m.dia} mmHg • Pouls: ${m.pulse ?? "-"}'
                : 'Glycémie: ${m.glucose?.toStringAsFixed(2)} g/L • ${_ctxLabel(m.glucoseContext)}';

            final subtitle = [
              dt,
              if ((m.note ?? '').trim().isNotEmpty) 'Note: ${m.note}',
            ].join(' • ');

            return Dismissible(
              key: ValueKey(m.id),
              background: Container(
                alignment: Alignment.centerLeft,
                padding: const EdgeInsets.only(left: 16),
                color: Colors.red.withOpacity(0.2),
                child: const Icon(Icons.delete, color: Colors.red),
              ),
              secondaryBackground: Container(
                alignment: Alignment.centerRight,
                padding: const EdgeInsets.only(right: 16),
                color: Colors.red.withOpacity(0.2),
                child: const Icon(Icons.delete, color: Colors.red),
              ),
              confirmDismiss: (_) async {
                return await showDialog<bool>(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: const Text('Supprimer ?'),
                    content: const Text('Tu veux supprimer cette mesure ?'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
                      FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Supprimer')),
                    ],
                  ),
                );
              },
              onDismissed: (_) async {
                // Find the raw item index in box by matching id (since we store maps)
                for (int idx = 0; idx < _box.length; idx++) {
                  final v = _box.getAt(idx);
                  if (v is Map && v['id'] == m.id) {
                    await _box.deleteAt(idx);
                    break;
                  }
                }
              },
              child: Card(
                child: ListTile(
                  leading: Icon(m.type == MeasureType.bp ? Icons.favorite : Icons.bloodtype),
                  title: Text(title),
                  subtitle: Text(subtitle),
                ),
              ),
            );
          },
        );
      },
    );
  }

  static String _ctxLabel(GlucoseContext? c) {
    switch (c) {
      case GlucoseContext.fasting:
        return "À jeun";
      case GlucoseContext.beforeMeal:
        return "Avant repas";
      case GlucoseContext.afterMeal:
        return "Après repas";
      case GlucoseContext.random:
        return "Aléatoire";
      default:
        return "—";
    }
  }
}

/// ============================
/// Charts (last 7 days)
/// ============================

class ChartsScreen extends StatelessWidget {
  const ChartsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder(
      valueListenable: _box.listenable(),
      builder: (context, Box b, _) {
        final all = getAllMeasurements();
        final from = DateTime.now().subtract(const Duration(days: 7));
        final last7 = all.where((m) => m.dateTime.isAfter(from)).toList()
          ..sort((a, c) => a.dateTime.compareTo(c.dateTime));

        final bp = last7.where((m) => m.type == MeasureType.bp && m.sys != null && m.dia != null).toList();
        final gl = last7.where((m) => m.type == MeasureType.glucose && m.glucose != null).toList();

        if (bp.isEmpty && gl.isEmpty) {
          return const Center(child: Text("Pas assez de données (7 derniers jours)."));
        }

        return ListView(
          padding: const EdgeInsets.all(12),
          children: [
            if (bp.isNotEmpty) _bpChart(bp),
            if (bp.isNotEmpty) const SizedBox(height: 16),
            if (gl.isNotEmpty) _glucoseChart(gl),
          ],
        );
      },
    );
  }

  Widget _bpChart(List<Measurement> bp) {
    final sysSpots = <FlSpot>[];
    final diaSpots = <FlSpot>[];

    for (int i = 0; i < bp.length; i++) {
      sysSpots.add(FlSpot(i.toDouble(), bp[i].sys!.toDouble()));
      diaSpots.add(FlSpot(i.toDouble(), bp[i].dia!.toDouble()));
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Tension (7 derniers jours)', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            SizedBox(
              height: 240,
              child: LineChart(
                LineChartData(
                  gridData: const FlGridData(show: true),
                  titlesData: const FlTitlesData(show: true),
                  borderData: FlBorderData(show: true),
                  lineBarsData: [
                    LineChartBarData(
                      spots: sysSpots,
                      isCurved: true,
                      dotData: const FlDotData(show: true),
                      barWidth: 3,
                    ),
                    LineChartBarData(
                      spots: diaSpots,
                      isCurved: true,
                      dotData: const FlDotData(show: true),
                      barWidth: 3,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),
            const Text('Astuce: plus de mesures = courbe plus utile.'),
          ],
        ),
      ),
    );
  }

  Widget _glucoseChart(List<Measurement> gl) {
    final spots = <FlSpot>[];
    for (int i = 0; i < gl.length; i++) {
      spots.add(FlSpot(i.toDouble(), gl[i].glucose!.toDouble()));
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Glycémie (7 derniers jours)', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 12),
            SizedBox(
              height: 240,
              child: LineChart(
                LineChartData(
                  gridData: const FlGridData(show: true),
                  titlesData: const FlTitlesData(show: true),
                  borderData: FlBorderData(show: true),
                  lineBarsData: [
                    LineChartBarData(
                      spots: spots,
                      isCurved: true,
                      dotData: const FlDotData(show: true),
                      barWidth: 3,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// ============================
/// Add measurement
/// ============================

class AddMeasurementScreen extends StatefulWidget {
  const AddMeasurementScreen({super.key});
  @override
  State<AddMeasurementScreen> createState() => _AddMeasurementScreenState();
}

class _AddMeasurementScreenState extends State<AddMeasurementScreen> {
  MeasureType type = MeasureType.bp;

  final sysCtrl = TextEditingController();
  final diaCtrl = TextEditingController();
  final pulseCtrl = TextEditingController();

  final glucoseCtrl = TextEditingController();
  GlucoseContext glucoseContext = GlucoseContext.fasting;

  final noteCtrl = TextEditingController();
  DateTime dateTime = DateTime.now();

  @override
  void dispose() {
    sysCtrl.dispose();
    diaCtrl.dispose();
    pulseCtrl.dispose();
    glucoseCtrl.dispose();
    noteCtrl.dispose();
    super.dispose();
  }

  String _id() => '${DateTime.now().millisecondsSinceEpoch}_${Random().nextInt(9999)}';

  Future<void> _pickDateTime() async {
    final d = await showDatePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
      initialDate: dateTime,
    );
    if (d == null) return;

    final t = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(dateTime),
    );
    if (t == null) return;

    setState(() {
      dateTime = DateTime(d.year, d.month, d.day, t.hour, t.minute);
    });
  }

  void _toast(String msg) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));

  void _clear() {
    setState(() {
      sysCtrl.clear();
      diaCtrl.clear();
      pulseCtrl.clear();
      glucoseCtrl.clear();
      noteCtrl.clear();
      dateTime = DateTime.now();
      type = MeasureType.bp;
      glucoseContext = GlucoseContext.fasting;
    });
  }

  void _save() {
    if (type == MeasureType.bp) {
      final sys = int.tryParse(sysCtrl.text.trim());
      final dia = int.tryParse(diaCtrl.text.trim());
      final pulse = int.tryParse(pulseCtrl.text.trim());

      if (sys == null || dia == null) {
        _toast('Entre SYS et DIA (ex: 120 / 80).');
        return;
      }

      addMeasurement(
        Measurement(
          id: _id(),
          dateTime: dateTime,
          type: MeasureType.bp,
          sys: sys,
          dia: dia,
          pulse: pulse,
          note: noteCtrl.text.trim().isEmpty ? null : noteCtrl.text.trim(),
        ),
      );

      _clear();
      _toast('Tension enregistrée ✅');
      return;
    }

    final g = double.tryParse(glucoseCtrl.text.trim().replaceAll(',', '.'));
    if (g == null) {
      _toast('Entre la glycémie (ex: 0.95).');
      return;
    }

    addMeasurement(
      Measurement(
        id: _id(),
        dateTime: dateTime,
        type: MeasureType.glucose,
        glucose: g,
        glucoseContext: glucoseContext,
        note: noteCtrl.text.trim().isEmpty ? null : noteCtrl.text.trim(),
      ),
    );

    _clear();
    _toast('Glycémie enregistrée ✅');
  }

  @override
  Widget build(BuildContext context) {
    final dtLabel = DateFormat('dd/MM/yyyy HH:mm').format(dateTime);

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Type de mesure', style: TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                SegmentedButton<MeasureType>(
                  segments: const [
                    ButtonSegment(value: MeasureType.bp, label: Text('Tension')),
                    ButtonSegment(value: MeasureType.glucose, label: Text('Glycémie')),
                  ],
                  selected: {type},
                  onSelectionChanged: (s) => setState(() => type = s.first),
                ),
                const SizedBox(height: 12),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Date & heure'),
                  subtitle: Text(dtLabel),
                  trailing: OutlinedButton(onPressed: _pickDateTime, child: const Text('Modifier')),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        if (type == MeasureType.bp) _bpForm(),
        if (type == MeasureType.glucose) _glucoseForm(),
        const SizedBox(height: 10),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              controller: noteCtrl,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Note (optionnel)',
                hintText: 'Ex: après sport, stress, médicament…',
                border: OutlineInputBorder(),
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),
        FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save), label: const Text('Enregistrer')),
        const SizedBox(height: 8),
        OutlinedButton(onPressed: _clear, child: const Text('Réinitialiser')),
      ],
    );
  }

  Widget _bpForm() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            const Align(
              alignment: Alignment.centerLeft,
              child: Text('Tension artérielle', style: TextStyle(fontWeight: FontWeight.w600)),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: sysCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'SYS (ex: 120)', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: diaCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'DIA (ex: 80)', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: pulseCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Pouls (optionnel) (ex: 72)',
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _glucoseForm() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            const Align(
              alignment: Alignment.centerLeft,
              child: Text('Glycémie', style: TextStyle(fontWeight: FontWeight.w600)),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: glucoseCtrl,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(labelText: 'Valeur (g/L) (ex: 0.95)', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<GlucoseContext>(
              value: glucoseContext,
              items: const [
                DropdownMenuItem(value: GlucoseContext.fasting, child: Text('À jeun')),
                DropdownMenuItem(value: GlucoseContext.beforeMeal, child: Text('Avant repas')),
                DropdownMenuItem(value: GlucoseContext.afterMeal, child: Text('Après repas')),
                DropdownMenuItem(value: GlucoseContext.random, child: Text('Aléatoire')),
              ],
              onChanged: (v) => setState(() => glucoseContext = v ?? GlucoseContext.fasting),
              decoration: const InputDecoration(labelText: 'Contexte', border: OutlineInputBorder()),
            ),
          ],
        ),
      ),
    );
  }
}

/// ============================
/// Security settings
/// ============================

class SecurityScreen extends StatefulWidget {
  const SecurityScreen({super.key});
  @override
  State<SecurityScreen> createState() => _SecurityScreenState();
}

class _SecurityScreenState extends State<SecurityScreen> {
  final lock = LockService();
  bool enabled = false;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    enabled = await lock.isEnabled();
    loading = false;
    setState(() {});
  }

  Future<void> _setPinFlow() async {
    final a = TextEditingController();
    final b = TextEditingController();
    String? err;

    await showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text('Définir un PIN'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: a,
                keyboardType: TextInputType.number,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'Nouveau PIN'),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: b,
                keyboardType: TextInputType.number,
                obscureText: true,
                decoration: InputDecoration(labelText: 'Confirmer', errorText: err),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
            FilledButton(
              onPressed: () async {
                final p1 = a.text.trim();
                final p2 = b.text.trim();
                if (p1.length < 4) {
                  setS(() => err = 'PIN minimum 4 chiffres');
                  return;
                }
                if (p1 != p2) {
                  setS(() => err = 'Les PIN ne correspondent pas');
                  return;
                }
                await lock.setPin(p1);
                await lock.setEnabled(true);
                setState(() => enabled = true);
                if (ctx.mounted) Navigator.pop(ctx);
              },
              child: const Text('Enregistrer'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(title: const Text('Sécurité')),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          SwitchListTile(
            title: const Text('Verrouiller l’application'),
            value: enabled,
            onChanged: (v) async {
              if (v) {
                if (!await lock.hasPin()) {
                  await _setPinFlow();
                } else {
                  await lock.setEnabled(true);
                  setState(() => enabled = true);
                }
              } else {
                await lock.setEnabled(false);
                setState(() => enabled = false);
              }
            },
          ),
          const Divider(),
          ListTile(
            title: const Text('Changer le PIN'),
            trailing: const Icon(Icons.chevron_right),
            onTap: _setPinFlow,
          ),
        ],
      ),
    );
  }
}

String _ctxLabel(GlucoseContext? c) {
  switch (c) {
    case GlucoseContext.fasting:
      return "À jeun";
    case GlucoseContext.beforeMeal:
      return "Avant repas";
    case GlucoseContext.afterMeal:
      return "Après repas";
    case GlucoseContext.random:
      return "Aléatoire";
    default:
      return "—";
  }
}
