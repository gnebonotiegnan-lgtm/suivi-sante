# Suivi Santé

Application Flutter simple (offline) pour enregistrer:
- Tension (SYS/DIA + pouls)
- Glycémie (g/L + contexte)

Fonctions:
- Historique + suppression
- Graphiques (7 derniers jours)
- Verrouillage PIN + biométrie (si dispo)

Compilation APK via GitHub Actions (workflow déjà inclus).
